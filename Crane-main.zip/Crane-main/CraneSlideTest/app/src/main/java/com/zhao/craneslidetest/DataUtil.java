package com.zhao.craneslidetest;

import android.text.TextUtils;

import com.zhao.craneslidetest.beans.CraneType;

/**
 * @author l30003406
 * @date 2020/11/4
 * @description
 */
public class DataUtil {

    /**
     * 判断测试数据消息体是否符合长度要求 26个字符
     *
     * @return
     */
    public static boolean isPackedComplete(String msg) {
        return (!TextUtils.isEmpty(msg)) && msg.length() == 26;
    }

    /**
     * 获取实时速度 十六进制字符串
     *
     * @param msg 消息内容
     * @return string
     */
    public static String getSpeedStr(String msg) {
        return msg.substring(0, 8);
    }

    /**
     * 获取制停减速度 十六进制字符串
     *
     * @param msg 消息内容
     * @return string
     */
    public static String getStopDecrease(String msg) {
        return msg.substring(8, 16);
    }

    /**
     * 获取下滑距离 十六进制字符串
     *
     * @param msg 消息内容
     * @return string
     */
    public static String getDistancesStr(String msg) {
        return msg.substring(16, 24);
    }

    /**
     * 获取触发状态 十六进制字符串
     *
     * @param msg 消息内容
     * @return string
     */
    public static String getStatus(String msg) {
        return msg.substring(24);
    }

    /**
     * 判断是否已触发
     *
     * @param status 00 表示未触发 ，01 表示已触发
     * @return true 已触发，false 未触发
     */
    public static boolean isTrigger(String status) {
        return TextUtils.equals("01", status);
    }

    /**
     * 判断是否已触发
     *
     * @param status 00 表示未触发 ，01 表示已触发
     * @return true 已触发，false 未触发
     */
    public static boolean isUnTrigger(String status) {
        return TextUtils.equals("00", status);
    }

    /**
     * 转换实时速度
     *
     * @param speedStr 十六进制字符串
     * @return float
     */
    public static float transformSpeed(String speedStr) {
        return Integer.parseInt(speedStr, 16) * 0.3f * 0.01f;
    }

    /**
     * 转换制停减速度
     *
     * @param stopDecreaseStr 十六进制字符串
     * @return float
     */
    public static float transformStopDecrease(String stopDecreaseStr) {
        return Integer.parseInt(stopDecreaseStr, 16) * 15f / 7 * 0.01f;
    }

    /**
     * 转换下滑距离
     *
     * @param disStr 十六进制字符串
     * @return float
     */
    public static float transformDistances(String disStr) {
        return Integer.parseInt(disStr, 16) * 0.06f * 0.01f;
    }

    public static CraneType generateCraneType(CraneType craneType) {
        CraneType data = new CraneType();
        data.setTimeStamp(System.currentTimeMillis());
        data.setCraneType(craneType.getCraneType());
        data.setCraneNum(craneType.getCraneNum());
        data.setRateQty(craneType.getRateQty());
        data.setMiniSpeed(craneType.getMiniSpeed());
        data.setInspectors(craneType.getInspectors());
        data.setRunSpeed(craneType.getRunSpeed());
        data.setStopDecrease(craneType.getStopDecrease());
        data.setStopDistance(craneType.getStopDistance());
        data.setTestResult(craneType.getTestResult());
        return data;
    }
}
