package com.zhao.craneslidetest.commonui;

import android.text.Editable;
import android.text.TextWatcher;

/**
 * @author l30003406
 * @date 2020/11/3
 * @description
 */
public class CSTextWatcher implements TextWatcher {

    private OnTextChangedListener mListener;

    public CSTextWatcher(OnTextChangedListener listener) {
        this.mListener = listener;
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        if (null != mListener) {
            mListener.onChanged(s);
        }
    }

    @Override
    public void afterTextChanged(Editable s) {

    }

    public interface OnTextChangedListener {
        void onChanged(CharSequence s);
    }
}
