package com.zhao.craneslidetest.beans;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;

/**
 * @Author : LiangGuoChang
 * @Date : 2020/11/1
 * @描述 : 对应起重机的图标的坐标单点数据
 */
@Entity
public class CraneResultChartData {

    @Id
    private Long id;

    //data id
    private long dataId;
    //时间戳
    private long timeStamp;
    //起重机类型
    private String craneType;
    //起重机编号
    private String craneNum;
    //实时速度(左Y轴)
    private String readSpeedLeft;
    //下滑距离(右Y轴)
    private String slipDistanceRight;

    @Generated(hash = 16531642)
    public CraneResultChartData(Long id, long dataId, long timeStamp,
                                String craneType, String craneNum, String readSpeedLeft,
                                String slipDistanceRight) {
        this.id = id;
        this.dataId = dataId;
        this.timeStamp = timeStamp;
        this.craneType = craneType;
        this.craneNum = craneNum;
        this.readSpeedLeft = readSpeedLeft;
        this.slipDistanceRight = slipDistanceRight;
    }

    @Generated(hash = 175385171)
    public CraneResultChartData() {
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public long getDataId() {
        return this.dataId;
    }

    public void setDataId(long dataId) {
        this.dataId = dataId;
    }

    public long getTimeStamp() {
        return this.timeStamp;
    }

    public void setTimeStamp(long timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getCraneType() {
        return this.craneType;
    }

    public void setCraneType(String craneType) {
        this.craneType = craneType;
    }

    public String getCraneNum() {
        return this.craneNum;
    }

    public void setCraneNum(String craneNum) {
        this.craneNum = craneNum;
    }

    public String getReadSpeedLeft() {
        return this.readSpeedLeft;
    }

    public void setReadSpeedLeft(String readSpeedLeft) {
        this.readSpeedLeft = readSpeedLeft;
    }

    public String getSlipDistanceRight() {
        return this.slipDistanceRight;
    }

    public void setSlipDistanceRight(String slipDistanceRight) {
        this.slipDistanceRight = slipDistanceRight;
    }


}
