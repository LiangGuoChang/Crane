package com.zhao.craneslidetest;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.PopupWindow;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zhao.craneslidetest.beans.CraneType;
import com.zhao.craneslidetest.commonui.CLoadingDialogManager;
import com.zhao.craneslidetest.commonui.DialogUtil;
import com.zhao.craneslidetest.dao.DaoManager;
import com.zhao.craneslidetest.databinding.ActivityTestResultSearchBinding;

import java.util.Calendar;
import java.util.List;

public class TestResultSearchActivity extends AppCompatActivity implements View.OnClickListener {

    private DatePicker mDatePicker;
    private Calendar mCalendar = null;
    private int mYear;
    private int mMonth;
    private int mDay;
    private PopupWindow mPopupWindow;//日期选择窗
    private ActivityTestResultSearchBinding mBinding;
    private PopupWindow mSearchResultWin;
    private CraneListAdapter mResultAdapter;
    private CLoadingDialogManager mLoadingDialogManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_test_result_search);
        mCalendar = Calendar.getInstance();
        mLoadingDialogManager = new CLoadingDialogManager(this);
        initView();
    }


    private void initView() {
        mBinding.setClickListener(this);
        mYear = mCalendar.get(Calendar.YEAR);
        mMonth = mCalendar.get(Calendar.MONTH);
        mDay = mCalendar.get(Calendar.DAY_OF_MONTH);
        mBinding.tvSelectDate.setText(TimeUtil.showTimeStr(mYear, mMonth, mDay));
    }

    //弹出日期选择窗
    private void showDatePickerWindow() {
        if (null == mPopupWindow) {
            View view = LayoutInflater.from(this).inflate(R.layout.date_picker_windows, null);
            mPopupWindow = new PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT);
            mPopupWindow.setOutsideTouchable(true);
            mDatePicker = view.findViewById(R.id.date_picker);
            view.findViewById(R.id.cancel_picker).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mPopupWindow.dismiss();
                    mBinding.tvSelectCrane.setCursorVisible(true);
                }
            });
            view.findViewById(R.id.ensure_picker).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mYear = mDatePicker.getYear();
                    mMonth = mDatePicker.getMonth();
                    mDay = mDatePicker.getDayOfMonth();

                    Log.d("TAG", "initView: " + mYear + mMonth + mDay);

                    mBinding.tvSelectDate.setText(TimeUtil.showTimeStr(mYear, mMonth, mDay));

                    mPopupWindow.dismiss();
                    mBinding.tvSelectCrane.setCursorVisible(true);
                }
            });
        }
        mPopupWindow.showAtLocation(this.getWindow().getDecorView(), Gravity.BOTTOM, 0, 0);
    }

    //弹出查询结果弹窗
    private void showResultWindow(List<CraneType> craneTypeList) {
        if (null == mSearchResultWin) {
            View view = LayoutInflater.from(this).inflate(R.layout.search_result_window, null);
            mSearchResultWin = new PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            view.findViewById(R.id.tv_dismiss_win).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mSearchResultWin.dismiss();
                }
            });
            RecyclerView resultRv = view.findViewById(R.id.rv_result_data);
            resultRv.setLayoutManager(new LinearLayoutManager(this));
            mResultAdapter = new CraneListAdapter(this);
            mResultAdapter.setItemClickListener(new CraneListAdapter.OnCraneItemClickListener() {
                @Override
                public void onItemClick(CraneType craneType) {
                    //点击事件
                    Intent intent = new Intent(TestResultSearchActivity.this, ItemResultActivity.class);
                    intent.putExtra(AppConstants.SUBMIT_CRANE_TYPE, craneType);
                    startActivity(intent);
                }
            });
            resultRv.setAdapter(mResultAdapter);
        }
        mSearchResultWin.showAtLocation(this.getWindow().getDecorView(), Gravity.CENTER, 0, 0);
        mResultAdapter.setData(craneTypeList);
        mResultAdapter.notifyDataSetChanged();
    }

    @Override
    public void onClick(View view) {
        hideSoftInput();
        int viewId = view.getId();
        if (viewId == R.id.tv_all_date || viewId == R.id.tv_all_crane) {//全部
            mLoadingDialogManager.showLoadingDialog(getString(R.string.searching_msg));
            List<CraneType> craneTypes = DaoManager.getInstance(this).searchByTimeOrCraneNum(-1, -1, "");
            if (null == craneTypes || craneTypes.isEmpty()) {
                DialogUtil.showToast(this, "未查询到相关数据");
            } else {
                Log.d("TAG", "onClick: " + craneTypes.size());
                showResultWindow(craneTypes);
            }
            mLoadingDialogManager.dismissLoadingDialog();
        } else if (viewId == R.id.tv_select_date) {//选择的日期
            showDatePickerWindow();
            mBinding.tvSelectCrane.setCursorVisible(false);
        } else if (viewId == R.id.btn_search_last_step) {//上一步
            this.finish();
        } else if (viewId == R.id.btn_search_result) {//查询
            mLoadingDialogManager.showLoadingDialog(getString(R.string.searching_msg));
            List<CraneType> craneTypes = DaoManager.getInstance(this).searchByTimeOrCraneNum(TimeUtil.getStartTimeStamp(mYear, mMonth, mDay),
                    TimeUtil.getEndTimeStamp(mYear, mMonth, mDay), mBinding.tvSelectCrane.getText().toString());
            if (null == craneTypes || craneTypes.isEmpty()) {
                DialogUtil.showToast(this, "未查询到相关数据");
            } else {
                Log.d("TAG", "onClick: " + craneTypes.size());
                showResultWindow(craneTypes);
            }
            mLoadingDialogManager.dismissLoadingDialog();
        }
    }

    private void hideSoftInput() {
        DialogUtil.hideSoftInput(this, this.getWindow().getDecorView().getWindowToken());
    }

}
