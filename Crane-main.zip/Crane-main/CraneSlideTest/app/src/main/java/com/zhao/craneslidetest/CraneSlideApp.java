package com.zhao.craneslidetest;

import android.app.Application;

/**
 * @author l30003406
 * @date 2020/11/12
 * @description
 */
public class CraneSlideApp extends Application {
    private static String mServiceIp;
    private static String mServicePort;

    @Override
    public void onCreate() {
        super.onCreate();
        //设置默认的ip 端口
        setServiceIp("192.168.137.1");
        setServicePort("2121");
    }

    public static String getServiceIp() {
        return mServiceIp;
    }

    public static void setServiceIp(String mServiceIp) {
        CraneSlideApp.mServiceIp = mServiceIp;
    }

    public static String getServicePort() {
        return mServicePort;
    }

    public static void setServicePort(String mServicePort) {
        CraneSlideApp.mServicePort = mServicePort;
    }
}
