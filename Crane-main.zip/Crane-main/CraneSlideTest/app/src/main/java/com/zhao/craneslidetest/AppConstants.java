package com.zhao.craneslidetest;

/**
 * @Author : LiangGuoChang
 * @Date : 2020/10/28
 * @描述 :
 */
public class AppConstants {
    //tcp 连接状态
    public static final int CONNECT_INIT = 0;//未连接
    public static final int CONNECTING = 1;//连接中
    public static final int CONNECT_SUCCESS = 2;//连接成功

    public static final String SUBMIT_CRANE_TYPE = "submitCraneType";
}
