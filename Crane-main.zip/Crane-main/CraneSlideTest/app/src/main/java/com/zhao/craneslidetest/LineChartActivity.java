package com.zhao.craneslidetest;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.zhao.craneslidetest.beans.CraneResultChartData;
import com.zhao.craneslidetest.beans.CraneType;
import com.zhao.craneslidetest.commonui.CLoadingDialogManager;
import com.zhao.craneslidetest.commonui.DialogUtil;
import com.zhao.craneslidetest.dao.DaoManager;
import com.zhao.craneslidetest.databinding.ActivityLineChartBinding;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class LineChartActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "LineChartActivity";
    //曲线编码
    private static final int SPEED_LINE = 0;
    private static final int DISTANCES_LINE = 1;
    private DecimalFormat mDecimalFormat = new DecimalFormat("#.00");   // 格式化浮点数位两位小数

    private ActivityLineChartBinding mBinding;
    private MutableLiveData<Boolean> mIsShowResult = new MutableLiveData<>();//显示结果
    private CraneType mSubmitCraneType;
    //图标相关
    private LineData mLineData; // 线集合，所有折现以数组的形式存到此集合中
    private XAxis mXAxis; //X轴
    private YAxis mLeftYAxis; //左侧Y轴，速度
    private YAxis mRightYAxis; //右侧Y轴，距离
    private Legend mLegend; //图例
    //未触发的实时速度，用来计算运行速度
    private List<Float> mUnTriggerSpeed = new ArrayList<>();
    //制停减速度
    private float mStopDecrease = 0.0f;

    // Y值数据链表
    private List<Float> mSpeedList = new ArrayList<>();//左侧Y轴，速度
    private List<Float> mDistanceList = new ArrayList<>();//右侧Y轴，距离
    // Chart需要的点数据链表
    List<Entry> mSpeedEntries = new ArrayList<>();
    List<Entry> mDisEntries = new ArrayList<>();
    // LineDataSet:点集合,即一条线
    LineDataSet mSpeedLineDataSet = new LineDataSet(mSpeedEntries, "速度");
    LineDataSet mDisLineDataSet = new LineDataSet(mDisEntries, "距离");

    //当前速度点数
    private int mCurSpeedPointCount = 0;
    //当前距离点数
    private int mCurDisPointCount = 0;

    private TcpService mTcpService;
    private boolean isBound = false;

    private CLoadingDialogManager mLoadingDialogManager;

    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            TcpService.TcpServiceBinder binder = (TcpService.TcpServiceBinder) service;
            mTcpService = binder.getTcpService();
            isBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_line_chart);
        mSubmitCraneType = getIntent().getParcelableExtra(AppConstants.SUBMIT_CRANE_TYPE);
        mLoadingDialogManager = new CLoadingDialogManager(this);

        //绑定服务
        Intent intent = new Intent(this, TcpService.class);
        bindService(intent, mConnection, BIND_AUTO_CREATE);

        initView();
        initLineChart();
    }

    @Override
    protected void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    private void initView() {
        mBinding.setClickListener(this);
        mBinding.setIsStarting(false);
        findViewById(R.id.btn_last_step).setOnClickListener(this);
        findViewById(R.id.btn_next_step).setOnClickListener(this);
        mIsShowResult.setValue(false);
        mIsShowResult.observe(this, new Observer<Boolean>() {
            @Override
            public void onChanged(Boolean aBoolean) {
                mBinding.setIsShowResult(aBoolean);
                Log.d(TAG, "onChanged: " + aBoolean);
                if (aBoolean) {
                    ((Button) mBinding.lastNextLayout.findViewById(R.id.btn_next_step)).setText("保存");
                } else {
                    ((Button) mBinding.lastNextLayout.findViewById(R.id.btn_next_step)).setText("下一步");
                }
            }
        });
    }

    //初始化图表
    private void initLineChart() {
        mXAxis = mBinding.dataLineChart.getXAxis();
        mLeftYAxis = mBinding.dataLineChart.getAxisLeft();
        mRightYAxis = mBinding.dataLineChart.getAxisRight();
        mLegend = mBinding.dataLineChart.getLegend();

        mLineData = new LineData();
        mBinding.dataLineChart.setData(mLineData);

        //速度y轴，距离y轴设置
        mSpeedLineDataSet.setAxisDependency(YAxis.AxisDependency.LEFT);
        mDisLineDataSet.setAxisDependency(YAxis.AxisDependency.RIGHT);
        mSpeedLineDataSet.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return "" + Float.parseFloat(mDecimalFormat.format(value));
            }
        });
        mDisLineDataSet.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return "" + Float.parseFloat(mDecimalFormat.format(value));
            }
        });

        //设置图表基本属性
        setLineChartAttrs(mBinding.dataLineChart);
        //设置xy轴
        setXYAxis(mBinding.dataLineChart, mXAxis, mLeftYAxis, mRightYAxis);
        //初始化线条
        initLine();
        //创建图例
        createLegend(mLegend);
    }


    /**
     * 设置图表基本属性
     */
    private void setLineChartAttrs(LineChart lineChart) {
        lineChart.setDrawGridBackground(true);//显示网格
        lineChart.setDrawBorders(true);//显示边界
        lineChart.setDragEnabled(true);//可以拖拽
        lineChart.setScaleEnabled(true);//可以缩放
        lineChart.setTouchEnabled(true);//有触摸事件
        //x轴放到 4倍，y轴不变
        Matrix matrix = new Matrix();
        matrix.postScale(6.0f, 2.0f);
        lineChart.getViewPortHandler().refresh(matrix, lineChart, false);
        //设置xy轴动画
        lineChart.animateY(500);
        lineChart.animateX(500);
    }

    /**
     * 设置XY轴
     */
    void setXYAxis(LineChart lineChart, XAxis xAxis, YAxis leftYAxis, YAxis rightYAxis) {
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM); //X轴设置显示位置在底部
        xAxis.setAxisMinimum(0f); // 设置X轴的最小值
        xAxis.setAxisMaximum(60); // 设置X轴的最大值
        xAxis.setLabelCount(150, false); // 设置X轴的刻度数量，第二个参数表示是否平均分配
        xAxis.setGranularity(1f); // 设置X轴坐标之间的最小间隔
        lineChart.setVisibleXRangeMaximum(60);// 当前统计图表中最多在x轴坐标线上显示的总量
        //保证Y轴从0开始，不然会上移一点
        leftYAxis.setAxisMinimum(0f);
        leftYAxis.setAxisMaximum(5f);
        leftYAxis.setGranularity(0.5f);
        leftYAxis.setLabelCount(40, false);
        //保留显示两位小数
        leftYAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return "" + Float.parseFloat(mDecimalFormat.format(value));
            }
        });

        rightYAxis.setAxisMinimum(0f);
        rightYAxis.setAxisMaximum(40f);
        rightYAxis.setGranularity(1f);
        rightYAxis.setLabelCount(40, false);
        //保留显示两位小数
        rightYAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return "" + Float.parseFloat(mDecimalFormat.format(value));
            }
        });

        lineChart.setVisibleYRangeMaximum(40, YAxis.AxisDependency.LEFT);// 当前统计图表中最多在Y轴坐标线上显示的总量
        lineChart.setVisibleYRangeMaximum(40, YAxis.AxisDependency.RIGHT);// 当前统计图表中最多在Y轴坐标线上显示的总量

//        leftYAxis.setCenterAxisLabels(true);// 将轴标记居中
//        leftYAxis.setDrawZeroLine(true); // 原点处绘制 一条线
//        leftYAxis.setZeroLineColor(Color.RED);
//        leftYAxis.setZeroLineWidth(1f);
    }


    /**
     * 对图表中的曲线初始化
     */
    private void initLine() {
        //新建速度曲线
        createLine(mSpeedList, mSpeedEntries, mSpeedLineDataSet, mLineData, mBinding.dataLineChart, Color.RED);
        //新建距离曲线
        createLine(mDistanceList, mDisEntries, mDisLineDataSet, mLineData, mBinding.dataLineChart, Color.BLUE);

        for (int i = 0; i < mLineData.getDataSetCount(); i++) {
            mBinding.dataLineChart.getLineData().getDataSets().get(i).setVisible(true);
        }
    }

    //新建一条线
    private void createLine(List<Float> yDataList, List<Entry> entries, LineDataSet lineDataSet, LineData lineData, LineChart lineChart, int color) {
        for (int i = 0; i < yDataList.size(); i++) {
            Entry entry = new Entry(i, yDataList.get(i));
            entries.add(entry);
        }
        //初始化线条
        initLineDataSet(lineDataSet, color, LineDataSet.Mode.LINEAR);
        if (null == lineData) {
            lineData = new LineData();
            lineData.addDataSet(lineDataSet);
            lineChart.setData(lineData);
        } else {
            lineChart.getLineData().addDataSet(lineDataSet);
        }

        //刷新
        lineChart.invalidate();
    }

    //初始化线条
    private void initLineDataSet(LineDataSet lineDataSet, int color, LineDataSet.Mode mode) {
        lineDataSet.setColor(color); // 设置曲线颜色
        lineDataSet.setCircleColor(color);  // 设置数据点圆形的颜色
        lineDataSet.setDrawCircleHole(false);// 设置曲线值的圆点是否是空心
        lineDataSet.setLineWidth(1f); // 设置折线宽度
        lineDataSet.setCircleRadius(3f); // 设置折现点圆点半径
        lineDataSet.setValueTextSize(10f);

        lineDataSet.setDrawFilled(true); //设置折线图填充
        lineDataSet.setFormLineWidth(1f);
        lineDataSet.setFormSize(15.f);
        if (mode == null) {
            //设置曲线展示为圆滑曲线（如果不设置则默认折线）
            lineDataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        } else {
            lineDataSet.setMode(mode);
        }
    }

    /**
     * 创建图例
     */
    private void createLegend(Legend legend) {
        legend.setForm(Legend.LegendForm.LINE);
        legend.setTextSize(12f);
        //左上
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legend.setDrawInside(false);
        legend.setEnabled(true);
    }

    /**
     * 给指定的线加一个点
     *
     * @param lineData
     * @param lineChart
     * @param yValue    y轴值
     * @param lineNum   线编码（速度、距离）
     */
    private void addEntry(LineData lineData, LineChart lineChart, float yValue, int lineNum) {
        //0.4s一个点
        float xValue = 0.0f;
        if (lineNum == SPEED_LINE) {
            xValue = mCurSpeedPointCount * 0.4f;
        } else if (lineNum == DISTANCES_LINE) {
            xValue = mCurDisPointCount * 0.4f;
        }
        Entry entry = new Entry(xValue, yValue);
        //添加点到指定的折线
        lineData.addEntry(entry, lineNum);
        //更新数据
        lineData.notifyDataChanged();
        lineChart.notifyDataSetChanged();

        //移动点到指定的位置
        if (lineNum == SPEED_LINE) {
            lineChart.moveViewToAnimated(xValue, yValue, YAxis.AxisDependency.LEFT, 1000);
            //点加1
            mCurSpeedPointCount++;
        } else if (lineNum == DISTANCES_LINE) {
            lineChart.moveViewToAnimated(xValue, yValue, YAxis.AxisDependency.RIGHT, 1000);
            //点加1
            mCurDisPointCount++;
        }

        lineChart.invalidate();
    }

    /**
     * 添加速度点
     */
    private void addSpeedLineEntry(float speedValue) {
        addEntry(mLineData, mBinding.dataLineChart, speedValue, SPEED_LINE);
    }

    /**
     * 添加距离点
     */
    private void addDistancesEntry(float disValue) {
        addEntry(mLineData, mBinding.dataLineChart, disValue, DISTANCES_LINE);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(String msg) {
        //接受下位机返还的消息,触发状态的数据才有速度与距离,已发送了开始测试 才添加点
        Log.d(TAG, "onMessageEvent: " + msg);
        if (mBinding.getIsStarting() && DataUtil.isPackedComplete(msg)) {
            if (DataUtil.isTrigger(DataUtil.getStatus(msg))) {
                // TODO: 2020/11/9 触发状态
                addSpeedLineEntry(DataUtil.transformSpeed(DataUtil.getSpeedStr(msg)));
                addDistancesEntry(DataUtil.transformDistances(DataUtil.getDistancesStr(msg)));
                //获取制停减速度，覆盖上一次的
                mStopDecrease = DataUtil.transformStopDecrease(DataUtil.getStopDecrease(msg));
                Log.d(TAG, "onMessageEvent: 添加点");
            }

            if (DataUtil.isUnTrigger(DataUtil.getStatus(msg))) {
                //未触发状态，收集实时速度
                mUnTriggerSpeed.add(DataUtil.transformSpeed(DataUtil.getSpeedStr(msg)));
            }
        }
    }

    // TODO: 2020/11/5 测试数据
    private String testData[] = new String[]{"0000010B00000020000005DC01", "000000FA000000190000051401"};

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btn_last_step) {//上一步
            if (null != mIsShowResult.getValue()) {
                if (mIsShowResult.getValue()) {//当前为保存
                    DialogUtil.showToast(this, "测试数据未保存");
                } else if (mBinding.getIsStarting()) {
                    DialogUtil.showToast(this, "测试未结束");
                } else {
                    this.finish();
                }
            }
        } else if (id == R.id.btn_next_step) {
            //下一步
            if (mBinding.getIsStarting()) {
                DialogUtil.showToast(this, "测试未结束");
                //todo 测试数据
                EventBus.getDefault().post(testData[new Random().nextInt(2)]);
            } else {
                if (null != mIsShowResult.getValue()) {
                    if (!mIsShowResult.getValue()) {//当前为下一步
                        if (mSpeedEntries.size() <= 0 && mDisEntries.size() <= 0) {
                            DialogUtil.showToast(this, "不存在测试数据");
                        } else {
                            //todo 计算最后结果
                            calculateTestResult();
                            //变成保存
                            mIsShowResult.setValue(true);
                            //显示结果
                            showResultData();
                        }
                    } else {//当前为保存,显示结果
                        mLoadingDialogManager.showLoadingDialog(getString(R.string.saving_msg));
                        try {
                            saveTestData();
                            //清除图表数据
                            clearLineChart();
                            //变成下一步
                            mIsShowResult.setValue(false);
                            mLoadingDialogManager.dismissLoadingDialog();
                        } catch (Exception e) {
                            Log.d(TAG, "onClick: " + e.toString());
                            mLoadingDialogManager.dismissLoadingDialog();
                        }
                    }
                }
            }

        } else if (id == R.id.btn_start_stop) {
            if (mBinding.getIsStarting()) {
                //结束测试
                if (isBound && null != mTcpService) {
                    mTcpService.sendStopTestMsg();
                    mBinding.setIsStarting(false);
                    DialogUtil.showToast(this, "结束测试");
                }
            } else {
                //开始测试
                if (isBound && null != mTcpService) {
                    mTcpService.sendStartTestMsg();
                    mBinding.setIsStarting(true);
                    DialogUtil.showToast(this, "开始测试");
                }
            }
        }
    }

    //计算测试结果
    private void calculateTestResult() {
        // TODO: 2020/11/9
        //运行速度
        float runSpeed = 0.0f;
        for (Float aFloat : mUnTriggerSpeed) {
            runSpeed += aFloat;
        }
        if (mUnTriggerSpeed.size() > 0) {
            runSpeed = runSpeed / mUnTriggerSpeed.size();
        }
        if (runSpeed == 0.0f) {
            mSubmitCraneType.setRunSpeed("数据不足");
        } else {
            mSubmitCraneType.setRunSpeed(String.valueOf(runSpeed));
        }
        //制停减速度
        if (mStopDecrease == 0.0f) {
            mSubmitCraneType.setStopDecrease("数据不足");
        } else {
            mSubmitCraneType.setStopDecrease(String.valueOf(mStopDecrease));
        }
        //下滑量距离
        if (mDisEntries.size() > 0) {
            mSubmitCraneType.setStopDistance(String.valueOf(mDisEntries.get(mDisEntries.size() - 1).getY()));
        } else {
            mSubmitCraneType.setStopDistance("数据不足");
        }

        //检验结果
        mSubmitCraneType.setTestResult("PASS");
    }

    //显示运行速度等结果
    private void showResultData() {
        mBinding.runSpeedLayout.tvParamKey.setText(R.string.crane_run_speed);
        mBinding.stopDisLayout.tvParamKey.setText(R.string.crane_stop_dis);
        mBinding.stopDecreaseLayout.tvParamKey.setText(R.string.crane_stop_decrease);
        mBinding.testResultLayout.tvParamKey.setText(R.string.crane_test_result);

        mBinding.runSpeedLayout.tvParamValue.setText(mSubmitCraneType.getRunSpeed());
        mBinding.stopDisLayout.tvParamValue.setText(mSubmitCraneType.getStopDistance());
        mBinding.stopDecreaseLayout.tvParamValue.setText(mSubmitCraneType.getStopDecrease());
        mBinding.testResultLayout.tvParamValue.setText(mSubmitCraneType.getTestResult());
    }

    //保存测试的点数据
    private void saveTestData() throws Exception {
        //先保存起重机类型等数据
        CraneType craneType = DataUtil.generateCraneType(mSubmitCraneType);
        long insert = DaoManager.getInstance(this).insert(craneType);
        Log.d(TAG, "saveTestData: " + insert);
        //再保存速度、距离等数据
        List<CraneResultChartData> craneResultChartData = new ArrayList<>();
        for (int i = 0; i < mSpeedEntries.size(); i++) {
            CraneResultChartData chartData = new CraneResultChartData();
            chartData.setDataId(i);
            chartData.setTimeStamp(craneType.getTimeStamp());
            chartData.setCraneType(craneType.getCraneType());
            chartData.setCraneNum(craneType.getCraneNum());
            chartData.setReadSpeedLeft(String.valueOf(mSpeedEntries.get(i).getY()));
            chartData.setSlipDistanceRight(String.valueOf(mDisEntries.get(i).getY()));

            craneResultChartData.add(chartData);
        }

        DaoManager.getInstance(this).insertList(craneResultChartData);

    }

    /**
     * 清除图表数据
     */
    private void clearLineChart() {
        mCurDisPointCount = 0;
        mCurSpeedPointCount = 0;

        mSpeedList.clear();
        mDistanceList.clear();

        mSpeedEntries.clear();
        mDisEntries.clear();

        mBinding.dataLineChart.moveViewTo(0f, 0f, YAxis.AxisDependency.LEFT);

        mBinding.dataLineChart.clearAllViewportJobs();
        mBinding.dataLineChart.removeAllViewsInLayout();
        mBinding.dataLineChart.removeAllViews();

        mBinding.dataLineChart.notifyDataSetChanged();
        mBinding.dataLineChart.invalidate();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (null != mConnection && isBound) {
            unbindService(mConnection);
        }

        EventBus.getDefault().unregister(this);

        mBinding.dataLineChart.clearAllViewportJobs();
        mBinding.dataLineChart.removeAllViewsInLayout();
        mBinding.dataLineChart.removeAllViews();
    }
}
