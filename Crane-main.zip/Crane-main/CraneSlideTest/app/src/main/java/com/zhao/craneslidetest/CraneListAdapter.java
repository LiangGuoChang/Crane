package com.zhao.craneslidetest;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.zhao.craneslidetest.beans.CraneType;
import com.zhao.craneslidetest.databinding.SearchItemLayoutBinding;

import java.util.List;

/**
 * @author l30003406
 * @date 2020/11/6
 * @description
 */
public class CraneListAdapter extends RecyclerView.Adapter<CraneListAdapter.CraneViewHolder> {

    private Context mContext;
    private List<CraneType> mData;
    private OnCraneItemClickListener mListener;

    public CraneListAdapter(Context context) {
        this.mContext = context;
    }

    public List<CraneType> getData() {
        return mData;
    }

    public void setData(List<CraneType> mData) {
        this.mData = mData;
        notifyDataSetChanged();
    }

    public void setItemClickListener(OnCraneItemClickListener mListener) {
        this.mListener = mListener;
    }

    @NonNull
    @Override
    public CraneViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        SearchItemLayoutBinding binding = DataBindingUtil.inflate(inflater, R.layout.search_item_layout, parent, false);
        return new CraneViewHolder(binding.getRoot());
    }

    @Override
    public void onBindViewHolder(@NonNull CraneViewHolder holder, final int position) {
        SearchItemLayoutBinding binding = DataBindingUtil.getBinding(holder.itemView);
        if (null != binding && null != mData && mData.size() > 0) {
            binding.setCraneType(mData.get(position));
            binding.setClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (null != mListener) {
                        mListener.onItemClick(mData.get(position));
                    }
                }
            });
        }

    }

    @Override
    public int getItemCount() {
        return null == mData ? 0 : mData.size();
    }

    static class CraneViewHolder extends RecyclerView.ViewHolder {

        CraneViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }


    interface OnCraneItemClickListener {
        void onItemClick(CraneType craneType);
    }
}
