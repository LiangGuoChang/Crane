package com.zhao.craneslidetest;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.Matrix;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.zhao.craneslidetest.beans.CraneResultChartData;
import com.zhao.craneslidetest.beans.CraneType;
import com.zhao.craneslidetest.dao.DaoManager;
import com.zhao.craneslidetest.databinding.ActivityItemResultBinding;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class ItemResultActivity extends AppCompatActivity implements View.OnClickListener {

    private DecimalFormat mDecimalFormat = new DecimalFormat("#.00");   // 格式化浮点数位两位小数
    private ActivityItemResultBinding mBinding;
    private CraneType mResultCrane;

    //图标相关
    private LineData mLineData; // 线集合，所有折现以数组的形式存到此集合中
    private XAxis mXAxis; //X轴
    private YAxis mLeftYAxis; //左侧Y轴，速度
    private YAxis mRightYAxis; //右侧Y轴，距离
    private Legend mLegend; //图例

    // Y值数据链表
    private List<Float> mSpeedList = new ArrayList<>();//左侧Y轴，速度
    private List<Float> mDistanceList = new ArrayList<>();//右侧Y轴，距离
    // Chart需要的点数据链表
    List<Entry> mSpeedEntries = new ArrayList<>();
    List<Entry> mDisEntries = new ArrayList<>();
    // LineDataSet:点集合,即一条线
    LineDataSet mSpeedLineDataSet = new LineDataSet(mSpeedEntries, "速度");
    LineDataSet mDisLineDataSet = new LineDataSet(mDisEntries, "距离");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_item_result);
        initView();
        initLineChart();
    }

    @SuppressLint("SetTextI18n")
    private void initView() {
        mBinding.setIsShowChart(false);
        mResultCrane = getIntent().getParcelableExtra(AppConstants.SUBMIT_CRANE_TYPE);
        mBinding.setClickListener(this);
        mBinding.craneType.tvResultKey.setText(R.string.crane_type);
        mBinding.craneNum.tvResultKey.setText(R.string.crane_num);
        mBinding.craneWeight.tvResultKey.setText(R.string.crane_rate_qty);
        mBinding.craneMiniSpeed.tvResultKey.setText(R.string.crane_mini_speed);
        mBinding.craneInspectors.tvResultKey.setText(R.string.crane_inspector);

        //显示运行速度等结果
        mBinding.resultRunSpeed.tvParamKey.setText(R.string.crane_run_speed);
        mBinding.resultStopDis.tvParamKey.setText(R.string.crane_stop_dis);
        mBinding.resultStopDecrease.tvParamKey.setText(R.string.crane_stop_decrease);
        mBinding.testResultLayout.tvParamKey.setText(R.string.crane_test_result);

        if (null != mResultCrane) {
            mBinding.craneType.tvResultValue.setText(TextUtils.isEmpty(mResultCrane.getCraneType()) ? "" : mResultCrane.getCraneType());
            mBinding.craneNum.tvResultValue.setText(TextUtils.isEmpty(mResultCrane.getCraneNum()) ? "" : mResultCrane.getCraneNum());
            mBinding.craneWeight.tvResultValue.setText(mResultCrane.getRateQty() + "  kg");
            mBinding.craneMiniSpeed.tvResultValue.setText(mResultCrane.getMiniSpeed() + "  cm/s");
            mBinding.craneInspectors.tvResultValue.setText(TextUtils.isEmpty(mResultCrane.getInspectors()) ? "" : mResultCrane.getInspectors());

            //显示运行速度等结果
            mBinding.resultRunSpeed.tvParamValue.setText(mResultCrane.getRunSpeed());
            mBinding.resultStopDis.tvParamValue.setText(mResultCrane.getStopDistance());
            mBinding.resultStopDecrease.tvParamValue.setText(mResultCrane.getStopDecrease());
            mBinding.testResultLayout.tvParamValue.setText(mResultCrane.getTestResult());
        }

        Log.d("TAG", "initView: " + mResultCrane.getTimeStamp());
        try {
            List<CraneResultChartData> craneResultChartData = DaoManager.getInstance(ItemResultActivity.this).searchChartData(mResultCrane);
            for (CraneResultChartData chartData : craneResultChartData) {
                mSpeedList.add(Float.parseFloat(chartData.getReadSpeedLeft()));
                mDistanceList.add(Float.parseFloat(chartData.getSlipDistanceRight()));
            }
            Log.d("TAG", "initView: " + craneResultChartData.size());
        } catch (Exception e) {
            Log.d("TAG", "initView: " + e.toString());
        }

    }

    private void initLineChart() {
        mXAxis = mBinding.resultLineChart.getXAxis();
        mLeftYAxis = mBinding.resultLineChart.getAxisLeft();
        mRightYAxis = mBinding.resultLineChart.getAxisRight();
        mLegend = mBinding.resultLineChart.getLegend();
        mLineData = new LineData();
        mBinding.resultLineChart.setData(mLineData);

        //速度y轴，距离y轴设置
        mSpeedLineDataSet.setAxisDependency(YAxis.AxisDependency.LEFT);
        mDisLineDataSet.setAxisDependency(YAxis.AxisDependency.RIGHT);
        mSpeedLineDataSet.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return "" + Float.parseFloat(mDecimalFormat.format(value));
            }
        });
        mDisLineDataSet.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return "" + Float.parseFloat(mDecimalFormat.format(value));
            }
        });

        //设置图表基本属性
        setLineChartAttrs(mBinding.resultLineChart);
        //设置xy轴
        setXYAxis(mBinding.resultLineChart, mXAxis, mLeftYAxis, mRightYAxis);
        //初始化线条
        initLine();
        //创建图例
        createLegend(mLegend);
    }

    /**
     * 设置图表基本属性
     */
    private void setLineChartAttrs(LineChart lineChart) {
        lineChart.setDrawGridBackground(true);//显示网格
        lineChart.setDrawBorders(true);//显示边界
        lineChart.setDragEnabled(true);//可以拖拽
        lineChart.setScaleEnabled(true);//可以缩放
        lineChart.setTouchEnabled(true);//有触摸事件
        //x轴放到 4倍，y轴不变
        Matrix matrix = new Matrix();
        matrix.postScale(6.0f, 2.0f);
        lineChart.getViewPortHandler().refresh(matrix, lineChart, false);
        //设置xy轴动画
        lineChart.animateY(500);
        lineChart.animateX(500);
    }

    /**
     * 设置XY轴
     */
    void setXYAxis(LineChart lineChart, XAxis xAxis, YAxis leftYAxis, YAxis rightYAxis) {
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM); //X轴设置显示位置在底部
        xAxis.setAxisMinimum(0f); // 设置X轴的最小值
        xAxis.setAxisMaximum(60); // 设置X轴的最大值
        xAxis.setLabelCount(150, false); // 设置X轴的刻度数量，第二个参数表示是否平均分配
        xAxis.setGranularity(1f); // 设置X轴坐标之间的最小间隔
        lineChart.setVisibleXRangeMaximum(60);// 当前统计图表中最多在x轴坐标线上显示的总量
        //保证Y轴从0开始，不然会上移一点
        leftYAxis.setAxisMinimum(0f);
        leftYAxis.setAxisMaximum(5f);
        leftYAxis.setGranularity(0.5f);
        leftYAxis.setLabelCount(40, false);
        //保留显示两位小数
        leftYAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return "" + Float.parseFloat(mDecimalFormat.format(value));
            }
        });

        rightYAxis.setAxisMinimum(0f);
        rightYAxis.setAxisMaximum(40f);
        rightYAxis.setGranularity(1f);
        rightYAxis.setLabelCount(40, false);
        //保留显示两位小数
        rightYAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return "" + Float.parseFloat(mDecimalFormat.format(value));
            }
        });

        lineChart.setVisibleYRangeMaximum(40, YAxis.AxisDependency.LEFT);// 当前统计图表中最多在Y轴坐标线上显示的总量
        lineChart.setVisibleYRangeMaximum(40, YAxis.AxisDependency.RIGHT);// 当前统计图表中最多在Y轴坐标线上显示的总量

//        leftYAxis.setCenterAxisLabels(true);// 将轴标记居中
//        leftYAxis.setDrawZeroLine(true); // 原点处绘制 一条线
//        leftYAxis.setZeroLineColor(Color.RED);
//        leftYAxis.setZeroLineWidth(1f);
    }

    /**
     * 对图表中的曲线初始化
     */
    private void initLine() {
        //新建速度曲线
        createLine(mSpeedList, mSpeedEntries, mSpeedLineDataSet, mLineData, mBinding.resultLineChart, Color.RED);
        //新建距离曲线
        createLine(mDistanceList, mDisEntries, mDisLineDataSet, mLineData, mBinding.resultLineChart, Color.BLUE);

        for (int i = 0; i < mLineData.getDataSetCount(); i++) {
            mBinding.resultLineChart.getLineData().getDataSets().get(i).setVisible(true);
        }
    }

    //新建一条线
    private void createLine(List<Float> yDataList, List<Entry> entries, LineDataSet lineDataSet, LineData lineData, LineChart lineChart, int color) {
        for (int i = 0; i < yDataList.size(); i++) {
            Entry entry = new Entry(i, yDataList.get(i));
            entries.add(entry);
        }
        //初始化线条
        initLineDataSet(lineDataSet, color, LineDataSet.Mode.LINEAR);
        if (null == lineData) {
            lineData = new LineData();
            lineData.addDataSet(lineDataSet);
            lineChart.setData(lineData);
        } else {
            lineChart.getLineData().addDataSet(lineDataSet);
        }

        //刷新
        lineChart.invalidate();
    }

    //初始化线条
    private void initLineDataSet(LineDataSet lineDataSet, int color, LineDataSet.Mode mode) {
        lineDataSet.setColor(color); // 设置曲线颜色
        lineDataSet.setCircleColor(color);  // 设置数据点圆形的颜色
        lineDataSet.setDrawCircleHole(false);// 设置曲线值的圆点是否是空心
        lineDataSet.setLineWidth(1f); // 设置折线宽度
        lineDataSet.setCircleRadius(3f); // 设置折现点圆点半径
        lineDataSet.setValueTextSize(10f);

        lineDataSet.setDrawFilled(true); //设置折线图填充
        lineDataSet.setFormLineWidth(1f);
        lineDataSet.setFormSize(15.f);
        if (mode == null) {
            //设置曲线展示为圆滑曲线（如果不设置则默认折线）
            lineDataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        } else {
            lineDataSet.setMode(mode);
        }
    }

    /**
     * 创建图例
     */
    private void createLegend(Legend legend) {
        legend.setForm(Legend.LegendForm.LINE);
        legend.setTextSize(12f);
        //左上
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legend.setDrawInside(false);
        legend.setEnabled(true);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btn_last_step) {
            if (mBinding.getIsShowChart()) {
                mBinding.setIsShowChart(false);
            } else {
                this.finish();
            }

        } else if (id == R.id.btn_next_step) {
            if (mBinding.getIsShowChart()) {
                mBinding.setIsShowChart(false);
            } else {
                mBinding.setIsShowChart(true);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
