package com.zhao.craneslidetest.beans;

import android.os.Parcel;
import android.os.Parcelable;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;

/**
 * @Author : LiangGuoChang
 * @Date : 2020/11/1
 * @描述 : 起重机类型表数据结构
 */
@Entity
public class CraneType implements Parcelable {

    @Id
    private Long id;

    //时间戳
    private long timeStamp;
    //起重机类型
    private String craneType;
    //起重机编号
    private String craneNum;
    //额定起重量 kg
    private int rateQty;
    //最小上升速度 cm/s
    private float miniSpeed;
    //检验人员
    private String inspectors;
    //运行速度
    private String runSpeed;
    //制停距离
    private String stopDistance;
    //制停减速度
    private String stopDecrease;
    //检验结果
    private String testResult;

    @Generated(hash = 1824676475)
    public CraneType(Long id, long timeStamp, String craneType, String craneNum,
                     int rateQty, float miniSpeed, String inspectors, String runSpeed,
                     String stopDistance, String stopDecrease, String testResult) {
        this.id = id;
        this.timeStamp = timeStamp;
        this.craneType = craneType;
        this.craneNum = craneNum;
        this.rateQty = rateQty;
        this.miniSpeed = miniSpeed;
        this.inspectors = inspectors;
        this.runSpeed = runSpeed;
        this.stopDistance = stopDistance;
        this.stopDecrease = stopDecrease;
        this.testResult = testResult;
    }

    @Generated(hash = 1122336503)
    public CraneType() {
    }

    protected CraneType(Parcel in) {
        if (in.readByte() == 0) {
            id = null;
        } else {
            id = in.readLong();
        }
        timeStamp = in.readLong();
        craneType = in.readString();
        craneNum = in.readString();
        rateQty = in.readInt();
        miniSpeed = in.readFloat();
        inspectors = in.readString();
        runSpeed = in.readString();
        stopDistance = in.readString();
        stopDecrease = in.readString();
        testResult = in.readString();
    }

    public static final Creator<CraneType> CREATOR = new Creator<CraneType>() {
        @Override
        public CraneType createFromParcel(Parcel in) {
            return new CraneType(in);
        }

        @Override
        public CraneType[] newArray(int size) {
            return new CraneType[size];
        }
    };

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public long getTimeStamp() {
        return this.timeStamp;
    }

    public void setTimeStamp(long timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getCraneType() {
        return this.craneType;
    }

    public void setCraneType(String craneType) {
        this.craneType = craneType;
    }

    public String getCraneNum() {
        return this.craneNum;
    }

    public void setCraneNum(String craneNum) {
        this.craneNum = craneNum;
    }

    public int getRateQty() {
        return this.rateQty;
    }

    public void setRateQty(int rateQty) {
        this.rateQty = rateQty;
    }

    public float getMiniSpeed() {
        return this.miniSpeed;
    }

    public void setMiniSpeed(float miniSpeed) {
        this.miniSpeed = miniSpeed;
    }

    public String getInspectors() {
        return this.inspectors;
    }

    public void setInspectors(String inspectors) {
        this.inspectors = inspectors;
    }

    public String getRunSpeed() {
        return this.runSpeed;
    }

    public void setRunSpeed(String runSpeed) {
        this.runSpeed = runSpeed;
    }

    public String getStopDistance() {
        return this.stopDistance;
    }

    public void setStopDistance(String stopDistance) {
        this.stopDistance = stopDistance;
    }

    public String getStopDecrease() {
        return this.stopDecrease;
    }

    public void setStopDecrease(String stopDecrease) {
        this.stopDecrease = stopDecrease;
    }

    public String getTestResult() {
        return this.testResult;
    }

    public void setTestResult(String testResult) {
        this.testResult = testResult;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        if (id == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeLong(id);
        }
        dest.writeLong(timeStamp);
        dest.writeString(craneType);
        dest.writeString(craneNum);
        dest.writeInt(rateQty);
        dest.writeFloat(miniSpeed);
        dest.writeString(inspectors);
        dest.writeString(runSpeed);
        dest.writeString(stopDistance);
        dest.writeString(stopDecrease);
        dest.writeString(testResult);
    }
}
