package com.zhao.craneslidetest;

import android.annotation.SuppressLint;
import android.text.TextUtils;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * @author l30003406
 * @date 2020/11/5
 * @description
 */
public class TimeUtil {

    private static final String TAG = "TimeUtil";
    private static final String TIME_PATTERN = "yyyy-MM-dd HH:mm:ss";

    /**
     * 将字符串转为时间戳
     *
     * @param dateString
     * @param pattern
     * @return
     */
    @SuppressLint("SimpleDateFormat")
    public static long getStringToDate(String dateString, String pattern) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        Date date = null;
        try {
            date = dateFormat.parse(dateString);
        } catch (ParseException e) {
            Log.d(TAG, "getStringToDate: " + e.toString());
        }

        return date == null ? -1 : date.getTime();
    }


    @SuppressLint("SimpleDateFormat")
    public static long getStartTimeStamp(int year, int monthOfYear, int dayOfMonth) {
        String startTime = getTimeStr(year, monthOfYear, dayOfMonth) + " 00:00:00";
        return getStringToDate(startTime, TIME_PATTERN);
    }

    @SuppressLint("SimpleDateFormat")
    public static long getEndTimeStamp(int year, int monthOfYear, int dayOfMonth) {
        String endTime = getTimeStr(year, monthOfYear, dayOfMonth) + " 23:59:59";
        return getStringToDate(endTime, TIME_PATTERN);
    }

    public static String getTimeStr(int year, int monthOfYear, int dayOfMonth) {
        String month = monthOfYear < 9 ? "0" + (monthOfYear + 1) : String.valueOf(monthOfYear + 1);
        String day = dayOfMonth < 9 ? "0" + dayOfMonth : String.valueOf(dayOfMonth);
        return year + "-" + month + "-" + day;
    }

    //显示
    public static String showTimeStr(int year, int monthOfYear, int dayOfMonth) {
        String month = monthOfYear < 9 ? "0" + (monthOfYear + 1) : String.valueOf(monthOfYear + 1);
        String day = dayOfMonth < 9 ? "0" + dayOfMonth : String.valueOf(dayOfMonth);
        return year + "" + month + "" + day;
    }


    //时间戳转换为字符串显示
    public static String getTimeStampToString(long timeStamp) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(TIME_PATTERN);
        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        String dateStr = dateFormat.format(new Date(timeStamp));
        return dateStr;
    }

    public static String getTimeStampToString(String timeStamp) {
        if (TextUtils.isEmpty(timeStamp)) {
            return TIME_PATTERN;
        }
        long time = Long.parseLong(timeStamp);
        return getTimeStampToString(time);
    }
}
