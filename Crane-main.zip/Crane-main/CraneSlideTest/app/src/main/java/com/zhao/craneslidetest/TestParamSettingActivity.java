package com.zhao.craneslidetest;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.zhao.craneslidetest.beans.CraneType;
import com.zhao.craneslidetest.commonui.CSTextWatcher;
import com.zhao.craneslidetest.commonui.DialogUtil;
import com.zhao.craneslidetest.databinding.ActivityTestParamSettingBinding;

public class TestParamSettingActivity extends AppCompatActivity implements View.OnClickListener {

    private String TAG = "TestParamSettingActivity";
    private ArrayAdapter mArrayAdapter;
    private CraneType mCraneType;
    private ActivityTestParamSettingBinding mBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_test_param_setting);
        initData();
        initView();
    }

    private void initData() {
        mArrayAdapter = ArrayAdapter.createFromResource(this, R.array.craneType, R.layout.spinner_item_layout);
        mArrayAdapter.setDropDownViewResource(R.layout.spinner_drop_item_layout);
        mCraneType = new CraneType();
    }

    private void initView() {
        mBinding.setClickListener(this);
        mBinding.craneSpinner.setAdapter(mArrayAdapter);
        findViewById(R.id.btn_last_step).setOnClickListener(this);
        findViewById(R.id.btn_next_step).setOnClickListener(this);
        mBinding.craneSpinner.setSelection(0);
        //类型下拉选择
        mBinding.craneSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.d(TAG, "onItemSelected: " + position);
                mCraneType.setCraneType((String) mBinding.craneSpinner.getItemAtPosition(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        //起重机编号输入框监听
        mBinding.etCraneNum.addTextChangedListener(new CSTextWatcher(new CSTextWatcher.OnTextChangedListener() {
            @Override
            public void onChanged(CharSequence s) {
                if (TextUtils.isEmpty(s)) {
                    mCraneType.setCraneNum("");
                } else {
                    mCraneType.setCraneNum(String.valueOf(s));
                }
            }
        }));
        //额定起重重量 TODO 不能太大
        mBinding.etRateQty.addTextChangedListener(new CSTextWatcher(new CSTextWatcher.OnTextChangedListener() {
            @Override
            public void onChanged(CharSequence s) {
                if (TextUtils.isEmpty(s)) {
                    mCraneType.setRateQty(0);
                } else {
                    mCraneType.setRateQty(Integer.parseInt(String.valueOf(s)));
                }
            }
        }));
        //最小上升速度
        mBinding.etMiniSpeed.addTextChangedListener(new CSTextWatcher(new CSTextWatcher.OnTextChangedListener() {
            @Override
            public void onChanged(CharSequence s) {
                if (TextUtils.isEmpty(s)) {
                    mCraneType.setMiniSpeed(0.0f);
                } else {
                    mCraneType.setMiniSpeed(Float.parseFloat(String.valueOf(s)));
                }
            }
        }));
        //检验人员
        mBinding.etInspectors.addTextChangedListener(new CSTextWatcher(new CSTextWatcher.OnTextChangedListener() {
            @Override
            public void onChanged(CharSequence s) {
                if (TextUtils.isEmpty(s)) {
                    mCraneType.setInspectors("");
                } else {
                    mCraneType.setInspectors(String.valueOf(s));
                }
            }
        }));
    }

    @Override
    public void onClick(View v) {
        hideSoftInput();
        int id = v.getId();
        if (id == R.id.btn_last_step) {
            //上一步
            this.finish();
        } else if (id == R.id.btn_next_step) {
            //下一步
            if (checkParam()) {
                Intent intent = new Intent(this, LineChartActivity.class);
                intent.putExtra(AppConstants.SUBMIT_CRANE_TYPE, mCraneType);
                startActivity(intent);
            }
        }
    }

    private void hideSoftInput() {
        DialogUtil.hideSoftInput(this, this.getWindow().getDecorView().getWindowToken());
    }

    //判断参数是否全部输入完成了
    private boolean checkParam() {
        if (null == mCraneType) {
            DialogUtil.showToast(this, "未设置参数");
            return false;
        }
        if (TextUtils.isEmpty(mCraneType.getCraneType())) {
            DialogUtil.showToast(this, "请选择起重机类型");
            return false;
        }
        if (TextUtils.isEmpty(mCraneType.getCraneNum())) {
            DialogUtil.showToast(this, "请输入起重机编号");
            return false;
        }
        if (mCraneType.getRateQty() <= 0) {
            DialogUtil.showToast(this, "额定起重量不能小于等于0");
            return false;
        }
        if (mCraneType.getMiniSpeed() <= 0.0f) {
            DialogUtil.showToast(this, "最小上升速度不能小于等于0");
            return false;
        }
        if (TextUtils.isEmpty(mCraneType.getInspectors())) {
            DialogUtil.showToast(this, "请检验人员");
            return false;
        }

        return true;
    }
}
