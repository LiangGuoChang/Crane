package com.zhao.craneslidetest.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.zhao.craneslidetest.beans.CraneResultChartData;
import com.zhao.craneslidetest.beans.CraneType;

import org.greenrobot.greendao.query.Query;

import java.util.ArrayList;
import java.util.List;

/**
 * @author l30003406
 * @date 2020/11/4
 * @description
 */
public class DaoManager {

    private Context mContext;
    private static DaoManager mDaoManager;
    private DaoMaster.DevOpenHelper mDevOpenHelper;
    private final CraneResultChartDataDao mCraneResultChartDataDao;
    private final CraneTypeDao mCraneTypeDao;

    public static DaoManager getInstance(Context context) {
        if (null == mDaoManager) {
            synchronized (DaoManager.class) {
                if (null == mDaoManager) {
                    mDaoManager = new DaoManager(context);
                }
            }
        }
        return mDaoManager;
    }

    public DaoManager(Context context) {
        this.mContext = context;
        mDevOpenHelper = new DaoMaster.DevOpenHelper(context, "crane_slide_data.db");
        DaoMaster daoMaster = new DaoMaster(getWritableDatabase(context));
        DaoSession daoSession = daoMaster.newSession();
        mCraneResultChartDataDao = daoSession.getCraneResultChartDataDao();
        mCraneTypeDao = daoSession.getCraneTypeDao();
    }

    private SQLiteDatabase getWritableDatabase(Context context) {
        if (null == mDevOpenHelper) {
            mDevOpenHelper = new DaoMaster.DevOpenHelper(context, "crane_slide_data.db");
        }
        return mDevOpenHelper.getWritableDatabase();
    }

    /**
     * ==========对起重机类型表进行操作
     */

    //插入或替换
    public long insertOrReplace(CraneType craneType) {
        return mCraneTypeDao.getSession().insertOrReplace(craneType);
    }

    //插入
    public long insert(CraneType craneType) {
        return mCraneTypeDao.insert(craneType);
    }

    //根据编号或者日期查询
    public List<CraneType> searchByTimeOrCraneNum(long startTime, long endTime, String craneNo) {
        if ((startTime == -1 || endTime == -1) && TextUtils.isEmpty(craneNo)) {
            //查询全部
            Query<CraneType> build = mCraneTypeDao.queryBuilder()
                    .orderDesc(CraneTypeDao.Properties.TimeStamp)
                    .build();
            return build.list();
        }
        if (startTime == -1 || endTime == -1) {
            //只根据编码查询
            Query<CraneType> build = mCraneTypeDao.queryBuilder()
                    .where(CraneTypeDao.Properties.CraneNum.eq(craneNo))
                    .orderDesc(CraneTypeDao.Properties.TimeStamp)
                    .build();
            return build.list();
        } else if (TextUtils.isEmpty(craneNo)) {
            //只根据日期查询
            Query<CraneType> build = mCraneTypeDao.queryBuilder()
                    .where(CraneTypeDao.Properties.TimeStamp.ge(startTime))
                    .where(CraneTypeDao.Properties.TimeStamp.le(endTime))
                    .orderDesc(CraneTypeDao.Properties.TimeStamp)
                    .build();

            return build.list();
        } else {
            //根据编号，日期查询
            Query<CraneType> build = mCraneTypeDao.queryBuilder()
                    .where(CraneTypeDao.Properties.CraneNum.eq(craneNo))
                    .where(CraneTypeDao.Properties.TimeStamp.ge(startTime))
                    .where(CraneTypeDao.Properties.TimeStamp.le(endTime))
                    .orderDesc(CraneTypeDao.Properties.TimeStamp)
                    .build();

            return build.list();
        }
    }

    /**
     * ==============对图表结果进行操作
     */

    //插入或替换
    public long insertOrReplace(CraneResultChartData craneResultChartData) {
        return mCraneResultChartDataDao.getSession().insertOrReplace(craneResultChartData);
    }

    //插入
    public long insert(CraneResultChartData craneResultChartData) {
        return mCraneResultChartDataDao.getSession().insert(craneResultChartData);
    }

    //批量插入
    public void insertList(List<CraneResultChartData> chartDataList) {
        if (null != chartDataList && !chartDataList.isEmpty()) {
            mCraneResultChartDataDao.insertInTx(chartDataList);
        }
    }

    //查询记录
    public List<CraneResultChartData> searchChartData(CraneType craneType) {
        if (null != craneType) {
            Query<CraneResultChartData> build = mCraneResultChartDataDao.queryBuilder()
                    .where(CraneResultChartDataDao.Properties.CraneNum.eq(craneType.getCraneNum()))
                    .where(CraneResultChartDataDao.Properties.TimeStamp.eq(craneType.getTimeStamp()))
                    .where(CraneResultChartDataDao.Properties.CraneType.eq(craneType.getCraneType()))
                    .build();
            return build.list();
        }
        return new ArrayList<>();
    }

}
